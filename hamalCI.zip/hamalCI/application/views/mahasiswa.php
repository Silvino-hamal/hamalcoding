 <div class="content-wrapper">
<section class="content-header">
      <h1>
        Estudante
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i>Home</a></li>
        <li class="active">Estudante</li>
      </ol>
    </section>
    <section class="content">
        <button class="btn btn-primary"data-toggle="modal" data-target="#exampleModal"><i class="fa fa-plus"></i>  Amenta Dadus Estudante</button>

        <a class="btn btn-danger" href="<?php  echo base_url('mahasiswa/print')?>"> <i class="fa fa-print"></i>Print</a>
         <a class="btn btn-warning" href="<?php  echo base_url('mahasiswa/pdf')?>"> <i class="fa fa-file"></i>Expor PDF</a>

        <table class="table">
            <tr>
            <th>No</th>
            <th>Nre</th>
      			<th>Naran</th>
      			<th>sexo</th>
      			<th>esc anterior</th>
      			<th>municipio</th>
      			<th>Fakuldade</th>
      			<th>Departemento</th>
            <th colspan="2">ASAUN</th>
            </tr>
           <?php
           $no=1;
           foreach ($mahasiswa as $mhs) :?>
           <tr>
                    <td><?php echo $no++?></td>
                    <td><?php echo $mhs->nre?></td>
                    <td><?php echo $mhs->naran?></td>
                    <td><?php echo $mhs->sexo?></td>
                    <td><?php echo $mhs->esc_ant?></td>
                    <td><?php echo $mhs->municipio?></td>
                    <td><?php echo $mhs->fakuldade?></td>
                    <td><?php echo $mhs->departemento?></td>
                    
                     <td><?php echo anchor('mahasiswa/detail/'.$mhs->nre, '<div class="btn btn-success btn-sm"><i class="fa fa-search-plus"></i></div>')?> </td>

                    <td onclick="javascript:return confirm('Hakarak Hamos Data Nee? ')"> <?php echo anchor('mahasiswa/hapus/'.$mhs->nre, '<div class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></div>')?> </td>
                     
                     <td><?php echo anchor('mahasiswa/edit/'.$mhs->nre, '<div class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></div>')?> </td>
                 
                   
           </tr>
        <?php endforeach; ?>
        </table>
    </section>
  
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalLabel">Form Input Data Estudante</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <?php echo form_open_multipart('mahasiswa/tambah_aksi')?>

            <div class="form-group">
            <label>Nre</label>
            <input type="text" name="nre" class="form-control">
            </div>

            <div class="form-group">
            <label>Naran Estudante</label>
            <input type="text" name="naran" class="form-control">
            </div>
            <div class="form-group">
            <label>Sexo</label>
            <input type="text" name="sexo" class="form-control">
            </div>

            <div class="form-group">
            <label>Escola Anterior</label>
            <input type="text" name="esc_ant" class="form-control">
            </div>

            <div class="form-group">
            <label>Municipio</label>
            <input type="text" name="municipio" class="form-control">
            </div>

            <div class="form-group">
            <label>Fakuldade</label>
            <select class="form Control" name="fakuldade">
              <option>ICT</option>
              <option>Economia</option>
            </select>
            </div>

            <div class="form-group">
           <label>Departemento</label>
        <select class="form" name="departemento" value="<?php echo $mhs->departemento ?>">
          <option>Teknik Informatik</option>
          <option>Manegamen Informatik</option>
          <option>Contabilidade Computer</option>
          <option>Negocio</option>
          <option>Bankaria</option>

        </select>
            </div>
            <div class="form-group">
            <label>Upload Foto</label>
            <input type="file" name="Foto" class="form-control">
            </div>

          <button type="reset" class="btn btn-danger" data-dismiss="modal">Reset</button>
        <button type="submit" class="btn btn-primary">Save</button>
       
       <?php echo form_close(); ?>
      </div>
    </div>
  </div>
</div>
</div>