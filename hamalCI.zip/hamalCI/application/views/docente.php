 <div class="content-wrapper">
<section class="content-header">
      <h1>
        Docente
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i>Home</a></li>
        <li class="active">Estudante</li>
      </ol>
    </section>
    <section class="content">
        <button class="btn btn-primary"data-toggle="modal" data-target="#exampleModal"><i class="fa fa-plus"></i>  Amenta Dadus Docente</button>

        <a class="btn btn-danger" href="<?php  echo base_url('docente/print')?>"> <i class="fa fa-print"></i>Print</a>
         <a class="btn btn-warning" href="<?php  echo base_url('docente/pdf')?>"> <i class="fa fa-file"></i>Expor PDF</a>

        <table class="table">
            <tr>
            <th>No</th>
            <th>Nip</th>
      			<th>Naran Docente</th>
      			<th>Sexo</th>
      			<th>Estatus</th>
      			<th>Municipio</th>
      			<th>Hela Fatin</th>
      			<th>Estudo Ikus</th>
            <th colspan="2">ASAUN</th>
            </tr>
           <?php
           $no=1;
           foreach ($docente as $dcn) :?>
           <tr>
                    <td><?php echo $no++?></td>
                    <td><?php echo $dcn->Nip?></td>
                    <td><?php echo $dcn->Naran_Dosente?></td>
                    <td><?php echo $dcn->Sexo?></td>
                    <td><?php echo $dcn->Status?></td>
                    <td><?php echo $dcn->Municipio?></td>
                    <td><?php echo $dcn->Hela_fatin?></td>
                    <td><?php echo $dcn->Studo_Ikus?></td>
                    
                     <td><?php echo anchor('mahasiswa/detail/'.$dcn->Nip, '<div class="btn btn-success btn-sm"><i class="fa fa-search-plus"></i></div>')?> </td>

                    <td onclick="javascript:return confirm('Hakarak Hamos Data Nee? ')"> <?php echo anchor('docente/hapus/'.$dcn->Nip, '<div class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></div>')?> </td>
                     
                     <td><?php echo anchor('docente/edit/'.$dcn->Nip, '<div class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></div>')?> </td>
                 
                   
           </tr>
        <?php endforeach; ?>
        </table>
    </section>
  
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalLabel">Form Input Data Docente</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <?php echo form_open_multipart('mahasiswa/tambah_aksi')?>

            <div class="form-group">
            <label>NIP</label>
            <input type="text" name="Nip" class="form-control">
            </div>

            <div class="form-group">
            <label>Naran Docente</label>
            <input type="text" name="Naran_Dosente" class="form-control">
            </div>
            <div class="form-group">
            <label>Sexo</label>
            <input type="text" name="Sexo" class="form-control">
            </div>

            <div class="form-group">
            <label>Status</label>
            <input type="text" name="Status" class="form-control">
            </div>

            <div class="form-group">
            <label>Municipio</label>
            <input type="text" name="Municipio" class="form-control">
            </div>

            <label>Enderesu</label>
            <input type="text" name="Hela_Fatin" class="form-control">
            </div>

            <div class="form-group">
           <label>Estudo Ikus</label>
        <select class="form" name="departemento" value="<?php echo $mhs->departemento ?>">
          <option>Licensiatura</option>
          <option>Diploma 3</option>
          <option>Masterado</option>
          <option>Dotirado</option>
          

        </select>
            </div>
            <div class="form-group">
            <label>Upload Foto</label>
            <input type="file" name="Foto" class="form-control">
            </div>

          <button type="reset" class="btn btn-danger" data-dismiss="modal">Reset</button>
        <button type="submit" class="btn btn-primary">Save</button>
       
       <?php echo form_close(); ?>
      </div>
    </div>
  </div>
</div>
</div>