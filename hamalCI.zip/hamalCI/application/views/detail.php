<div class="content-wrapper">
	<section class="content">
		<h4> <strong>DADUS ESTUDANTE DETAIL</strong></h4>
		<table class="table">
			<tr>
				<th>NIM</th>
				<td><?php echo $detail->nre ?></td>
			</tr>

			<tr>
				<th>Naran</th>
				<td><?php echo $detail->naran ?></td>
			</tr>

			<tr>
				<th>Sexo</th>
				<td><?php echo $detail->sexo ?></td>
			</tr>

			<tr>
				<th>Escola Anterior</th>
				<td><?php echo $detail->esc_ant ?></td>
			</tr>

			<tr>
				<th>Municipio</th>
				<td><?php echo $detail->municipio ?></td>
			</tr>

			<tr>
				<th>Fakuldade</th>
				<td><?php echo $detail->fakuldade ?></td>
			</tr>

			<tr>
				<th>Departemento</th>
				<td><?php echo $detail->departemento ?></td>
			</tr>

			<tr>
				<td> 
					<img src=" <?php echo base_url(); ?>assets/foto/<?php echo $detail->Foto; ?>"
					width="100" height="110">
				</td>
			</tr> 


		</table>
		<a href="<?php echo base_url('mahasiswa/index'); ?>" class="btn btn-primary">FILA </a>
	</section>
</div>