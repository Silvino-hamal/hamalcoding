<!DOCTYPE html>
<html><head>
	<title></title>
</head><body>
	<table>
		<tr>
			<th>Nre</th>
			<th>Naran</th>
			<th>Sexo</th>
			<th>Escola Anterior</th>
			<th>Municipio</th>
			<th>Fakuldade</th>
			<th>Departemento</th>
		</tr>
		<?php 
		$no=1;
		foreach ($mahasiswa as $mhs):?>
			<tr>
				<td><?php echo $no++ ?></td>
				<td><?php echo $mhs->nre ?></td>
				<td><?php echo $mhs->naran ?></td>
				<td><?php echo $mhs->sexo ?></td>
				<td><?php echo $mhs->esc_ant ?></td>
				<td><?php echo $mhs->municipio ?></td>
				<td><?php echo $mhs->fakuldade ?></td>
				<td><?php echo $mhs->departemento ?></td>
			</tr> 
		<?php endforeach; ?>
	</table>
</body></html>