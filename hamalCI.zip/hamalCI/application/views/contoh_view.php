<!DOCTYPE html>
<html>
<head>
	<title>contoh view</title>
</head>
<body>
<h1>contoh view iha codeigniter</h1>
</body>
</html>