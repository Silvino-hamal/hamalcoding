<div class="content-wrapper">
	<section class="content">
		<?php foreach ($mahasiswa as $mhs ){ ?>
		<form action="<?php echo base_url().'mahasiswa/update'?>" method="post">
			<div class="form-group">
				<label>Nre</label>
				<input type="text" name="nre" class="form-control" value="<?php echo $mhs->nre?>"> 
			</div>
			<div class="form-group">
				<label>Naran</label>
				<input type="text" name="naran" class="form-control" value="<?php echo $mhs->naran?>">
			</div>

			<div class="form-group">
				<label>Sexo</label>
				<input type="text" name="sexo" class="form-control" value="<?php echo $mhs->sexo?>">
			</div>
			<div class="form-group">
				<label>Escola Anterior</label>
				<input type="text" name="esc_ant" class="form-control" value="<?php echo $mhs->esc_ant?>">
			</div>
			<div class="form-group">
				<label>Municipio</label>
				<input type="text" name="municipio" class="form-control" value="<?php echo $mhs->municipio?>">
			</div>
			<div class="form-group">
				<label>Fakuldade</label>
				  <select class="form Control" name="fakuldade"value="<?php echo $mhs->fakuldade?>">
	              <option>ICT</option>
	              <option>Economia</option>
            </select>
			</div>

			<div class="form-group">
				<label>Departemento</label>
				<select class="form" name="departemento" value="<?php echo $mhs->departemento ?>">
					<option>Teknik Informatik</option>
					<option>Manegamen Informatik</option>
					<option>Contabilidade Computer</option>
					<option>Negocio</option>
					<option>Bankaria</option>

				</select>	
			</div>

			 </div>
            <button type="reset" class="btn btn-danger">Reset</button>
			<button type="submit" class="btn btn-primary">Save</button>


		</form>


	<?php } ?>
	</section>
</div>