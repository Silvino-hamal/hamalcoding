<?php
class mahasiswa extends CI_controller{
    public function index()
    {
        $data['mahasiswa']=$this->m_mahasiswa->tampil_data()->result();
        $this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('mahasiswa',$data);
		$this->load->view('templates/footer');
    }
    public function tambah_aksi(){
        $nre           =$this->input->post('nre');
        $naran          =$this->input->post('naran');
        $sexo           =$this->input->post('sexo');
        $esc_ant          =$this->input->post('esc_ant');
        $municipio          =$this->input->post('municipio');
        $fakuldade           =$this->input->post('fakuldade');
        $departemento           =$this->input->post('departemento');
        $Foto                   =$_FILES['Foto'];
        if ($Foto=''){}else{
            $config['upload_path']   ='./assets/foto';
            $config['allowed_types'] ='jpg|pnj|gif';

            $this->load->library('upload', $config);
            if(!$this->upload->do_upload('Foto')){
                echo "upload gagal";die();
            }else{
                $Foto=$this->upload->data('file_name');
            }
        }

        $data= array(
            'nre'        =>$nre,
            'naran'      =>$naran,
            'sexo'         =>$sexo,
            'esc_ant'    =>$esc_ant,
            'municipio'  =>$municipio,
            'fakuldade'   =>$fakuldade,
            'departemento'  =>$departemento,
            'Foto'          =>$Foto,
        );
       $this->m_mahasiswa->input_data($data, 'tb_estudante');
        redirect('mahasiswa/index');
    }
   
   public function hapus($nre)
   {
    $where=array('nre' => $nre);
    $this->m_mahasiswa->hapus_data($where, 'tb_estudante');
    redirect('mahasiswa/index');
   }

   public function edit($nre)
   {
    $where=array('nre'=>$nre);
    $data['mahasiswa']=$this->m_mahasiswa->edit_data($where,'tb_estudante')->result();
         $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('edit',$data);
        $this->load->view('templates/footer');

   }
 
    public function update(){
        $nre              =$this->input->post('nre');
        $naran            =$this->input->post('naran');
        $sexo             =$this->input->post('sexo');
        $esc_ant          =$this->input->post('esc_ant');
        $municipio        =$this->input->post('municipio');
        $fakuldade        =$this->input->post('fakuldade');
        $departemento     =$this->input->post('departemento');


        $data=array( 
            'nre'      =>$nre,
            'naran'     =>$naran,
            'sexo'     =>$sexo,
            'esc_ant'     =>$esc_ant,
            'municipio'     =>$municipio,
            'fakuldade'     =>$fakuldade,
            'departemento'     =>$departemento
        );
        $where=array(
            'nre'=>$nre
        );

        $this->m_mahasiswa->update_data($where,$data, 'tb_estudante');
        redirect('mahasiswa/index');

    }

    public function detail($nre){
        $this->load->model('m_mahasiswa');/*load model*/
        $detail=$this->m_mahasiswa->detail_data($nre); /*FUNCTION IHA m_mahasiswa, no detail_data:nama function*/
        $data['detail'] =$detail;
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('detail', $data);
        $this->load->view('templates/footer');
    }
    
     public function print_data(){
        $data['mahasiswa']=$this->m_mahasiswa->tampil_data("tb_estudante")->result();
        $this->load->view('print_mahasiswa',$data);
     }

     public function pdf(){
        $this->load->library('dompdf_gen');
        $data['mahasiswa']=$this->m_mahasiswa->tampil_data("tb_estudante")->result();
        $this->load->view('laporan_pdf',$data);

        $paper_size='A4';
        $orientation='landscape';
        $html=$this->output->get_output();
        $this->dompdf->set_paper($paper_size, $orientation);

        $this->dompdf->load_html($html);
        $this->dompdf->render();
        $this->dompdf->stream("lapor_mahasiswa.pdf", array('attachment'=>0));
     }
}     
