<?php
class docente extends CI_controller{
    public function index()
    {
        $data['docente']=$this->m_docente->tampil_data()->result();
        $this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('mahasiswa',$data);
		$this->load->view('templates/footer');
    }
    public function tambah_aksi(){
        $Nip              =$this->input->post('Nip');
        $Naran_Dosente          =$this->input->post('Naran_Dosente ');
        $Sexo           =$this->input->post('Sexo');
        $Status          =$this->input->post('Status ');
        $Municipio          =$this->input->post('Municipio');
        $Hela_Fatin           =$this->input->post('Hela_Fatin ');
        $Studo_Ikus           =$this->input->post('Studo_Ikus ');
        $Foto                   =$_FILES['Foto'];
        if ($Foto=''){}else{
            $config['upload_path']   ='./assets/foto';
            $config['allowed_types'] ='jpg|pnj|gif';

            $this->load->library('upload', $config);
            if(!$this->upload->do_upload('Foto')){
                echo "upload gagal";die();
            }else{
                $Foto=$this->upload->data('file_name');
            }
        }

        $data= array(
            'Nip'               =>$Nip,
            'Naran_Dosente'      =>$Naran_Dosente,
            'Sexo'              =>$Sexo,
            'Status'             =>$Status,
            'Municipio'           =>$Municipio,
            'Hela_Fatin'          =>$Hela_Fatin,
            'Studo_Ikus'           =>$tudo_Ikus,
            'Foto'                  =>$Foto,
        );
       $this->m_docente->input_data($data, 'tb_dosente');
        redirect('docente/index');
    }
   
   public function hapus($Nip)
   {
    $where=array('Nip' => $Nip);
    $this->m_doccente->hapus_data($where, 'tb_dosente');
    redirect('docente/index');
   }

   public function edit($Nip)
   {
    $where=array('Nip'=>$Nip);
    $data['docente']=$this->m_docente->edit_data($where,'tb_dosente')->result();
         $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('edit',$data);
        $this->load->view('templates/footer');

   }
 
    public function update(){
         $Nip                     =$this->input->post('Nip');
        $Naran_Dosente            =$this->input->post('Naran_Dosente ');
        $Sexo                     =$this->input->post('Sexo');
        $Status                     =$this->input->post('Status ');
        $Municipio                =$this->input->post('Municipio');
        $Hela_Fatin                   =$this->input->post('Hela_Fatin ');
        $Studo_Ikus              =$this->input->post('Studo_Ikus ');

        $data=array( 
            'Nip'               =>$Nip,
            'Naran_Dosente'      =>$Naran_Dosente,
            'Sexo'              =>$Sexo,
            'Status'             =>$Status,
            'Municipio'           =>$Municipio,
            'Hela_Fatin'          =>$Hela_Fatin,
            'Studo_Ikus'           =>$tudo_Ikus,
            'Foto'                  =>$Foto,
        );
        $where=array(
            'Nip'=>$Nip
        );

        $this->m_docente->update_data($where,$data, 'tb_dosente');
        redirect('docente/index');

    }

    public function detail($Nip){
        $this->load->model('m_docente');/*load model*/
        $detail=$this->m_docente->detail_data($Nip); /*FUNCTION IHA m_mahasiswa, no detail_data:nama function*/
        $data['detail'] =$detail;
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('detail', $data);
        $this->load->view('templates/footer');
    }
    
     public function print_data(){
        $data['docente']=$this->m_docente->tampil_data("tb_dosente")->result();
        $this->load->view('print_docente',$data);
     }

     public function pdf(){
        $this->load->library('dompdf_gen');
        $data['mahasiswa']=$this->m_mahasiswa->tampil_data("tb_estudante")->result();
        $this->load->view('laporan_pdf',$data);

        $paper_size='A4';
        $orientation='landscape';
        $html=$this->output->get_output();
        $this->dompdf->set_paper($paper_size, $orientation);

        $this->dompdf->load_html($html);
        $this->dompdf->render();
        $this->dompdf->stream("lapor_mahasiswa.pdf", array('attachment'=>0));
     }
}     
